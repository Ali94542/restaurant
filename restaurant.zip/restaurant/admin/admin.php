<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Double Slider Login/ Registration Form</title>
   <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
   <link rel="stylesheet" href="../css/style(1).css">
</head>
<body>
<div class="wrapp">
   <span class="icon-close"><ion-icon name="close"></ion-icon>X</span>
   <div class="form-box login">
     <h2>Login</h2>
     <form action="login.php" method="post">
         <div class="input-box">
          <span class="icon"><ion-icon name="mail"></ion-icon></span>
          <input type="text"required name="name">
          <label >Name</label>
         </div>
         <div class="input-box">
          <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
          <input type="password" required name="password">
          <label>Password</label>
         </div>
         <div class="remember-forgot">
          <label><input type="checkbox">Remembr me</label>
          <a href="#">Forgot password?</a>
         </div>
         <button name="login" class="btn">Login</button>
     </form>
   </div>
</div>
<script src="js/script(1).js"></script>
</body>
</html>