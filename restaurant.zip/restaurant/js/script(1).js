document.querySelector('.icon-close').addEventListener('click', function() {
    // Go back to the previous page
    history.back();
  });