<?php
session_start();
include("./config/connect.php");
// Assuming you have a database connection established

// Check if the form was submitted
/*if (isset($_POST['submit'])) {
    // Retrieve the form data
    $id= $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Perform validation on the form data if required
    
    // Update the employee information in the database
    // Replace the following code with your database update logic
    // Example using MySQLi
    $query = "UPDATE admin SET name='$name', email='$email', password='$password' where id='$id'";
    $result = mysqli_query($con, $query);
    
    // Check if the update was successful
    if ($result) {
        // Redirect or display a success message
        header("location:table.php");
    } else {
        // Display an error message
        echo "Error updating employee information: " . mysqli_error($connection);
    }
}*/
if(isset($_GET['id'])){
    $id= $_GET['id'];
    echo $id;
    /*$query="SELECT * from admin where id='$id";
    $query_run= mysqli_query($con,$query);*/
}
?>
