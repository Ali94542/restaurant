<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Number ONE - Amazing & Delicious Food</title>
  <meta name="title" content="Number ONE - Amazing & Delicious Food">
  <meta name="description" content="This is a Restaurant html template made by ali ghader">
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Forum&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="./css/style.css">
</head>
<body id="top">
<main>
    <article>
      <section class="section menu" aria-label="menu-label" id="menu">
        <div class="container">

          <p class="section-subtitle text-center label-2">Special Selection</p>

          <h2 class="headline-1 section-title text-center">Delicious Menu</h2>

          <ul class="grid-list">

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-1.jpg" width="100" height="100" loading="lazy" alt="Greek Salad"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">Junck Burger</a>
                    </h3>

                    <span class="badge label-1">Seasonal</span>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                    BBQ sauce, cheddar sauce, mozzarella panee...
                  </p>

                </div>

              </div>
            </li>

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-2.jpg" width="100" height="100" loading="lazy" alt="Lasagne"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">Eiffel Tower Burger</a>
                    </h3>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                    Three burger, extra cheddar.
                  </p>

                </div>

              </div>
            </li>

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-3.jpg" width="100" height="100" loading="lazy" alt="Butternut Pumpkin"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">Polo A La Kieve</a>
                    </h3>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                    Salat polo, two ascalope + mozzarella + cheddar chease,fries.
                  </p>

                </div>

              </div>
            </li>

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-4.jpg" width="100" height="100" loading="lazy" alt="Tokusen Wagyu"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">Pizza Pepperoni</a>
                    </h3>

                    <span class="badge label-1">New</span>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                    Sousce pizza, mozzarella, Pepperoni.
                  </p>

                </div>

              </div>
            </li>

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-5.jpg" width="100" height="100" loading="lazy" alt="Olivas Rellenas"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">Mashawi Plate (Large 8)</a>
                    </h3>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                     Four pc kabab, two pc tawook, two pc meat + fries.
                  </p>

                </div>

              </div>
            </li>

            <li>
              <div class="menu-card hover:card">

                <figure class="card-banner img-holder" style="--width: 100; --height: 100;">
                  <img src="./images/menu-6.jpg" width="100" height="100" loading="lazy" alt="Opu Fish"
                    class="img-cover">
                </figure>

                <div>

                  <div class="title-wrapper">
                    <h3 class="title-3">
                      <a href="#" class="card-title">8 Pcs Broasted</a>
                    </h3>

                    <span class="span title-2">$</span>
                  </div>

                  <p class="card-text label-1">
                    coleslaw + fries.
                  </p>

                </div>

              </div>
            </li>

          </ul>
    </article>
</main>
</body>
</html> 