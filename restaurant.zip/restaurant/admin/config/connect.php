<?php
$db_host= "localhost";
$db_username= "root";
$db_pass= "";
$db_name= "resto";
$con=mysqli_connect($db_host,$db_username,$db_pass,$db_name);
if(mysqli_connect_error()){
   echo'connection error';
   mysqli_connect_error();
   exit();
}
?>