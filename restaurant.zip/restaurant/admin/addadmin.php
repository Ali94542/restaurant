<?php
    session_start();
    include("./config/connect.php");
    if(isset($_POST["submit"])){
        $name= $_POST["name"];
        $email= $_POST["email"];
        $password= $_POST["password"];
        $select="select * from admin where name = '$name' and password = '$password'";
        $result =mysqli_query($con, $select);
        if(mysqli_num_rows($result) > 0){
            echo '<script>
              window.location.href="table.php";
              alert("User already exist! Choose another account")
            </script>';
        }
        else{
        $sql = "INSERT INTO admin(name,email,password) values('$name','$email','$password')";
        mysqli_query($con, $sql);
        header("location:table.php");
    }
}
?>