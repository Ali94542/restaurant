<?php
    session_start();
    include("../db_config/connect.php");
    if(isset($_POST["login"])){
        $name= $_POST["name"];
        $password= $_POST["password"];
        $sql = "select * From admin where name = '$name' and password = '$password'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);
        if($count==1){
            header("location:adminpage.php");
        }
        else{
            echo '<script>
            window.location.href="admin.php";
            alert("login failed. Invalid password or email!")
         </script>';
        }
    }
?>